import React from 'react';

const STARS: { cx: number; cy: number; r: number; o: number; cross?: boolean }[] = [
  { cx: 110, cy: 58, r: 1.4, o: 0.75 },
  { cx: 195, cy: 112, r: 1.1, o: 0.5 },
  { cx: 268, cy: 46, r: 1.8, o: 0.85, cross: true },
  { cx: 342, cy: 138, r: 1.2, o: 0.45 },
  { cx: 430, cy: 76, r: 1.5, o: 0.7 },
  { cx: 518, cy: 42, r: 1.1, o: 0.6 },
  { cx: 590, cy: 118, r: 1.6, o: 0.55 },
  { cx: 675, cy: 64, r: 2.0, o: 0.9, cross: true },
  { cx: 760, cy: 146, r: 1.1, o: 0.45 },
  { cx: 838, cy: 54, r: 1.4, o: 0.7 },
  { cx: 912, cy: 96, r: 1.2, o: 0.5 },
  { cx: 996, cy: 48, r: 1.7, o: 0.85, cross: true },
  { cx: 1084, cy: 122, r: 1.3, o: 0.55 },
  { cx: 1168, cy: 70, r: 1.5, o: 0.75 },
  { cx: 1255, cy: 144, r: 1.1, o: 0.45 },
  { cx: 1330, cy: 52, r: 1.9, o: 0.88, cross: true },
  { cx: 1418, cy: 98, r: 1.3, o: 0.65 },
  { cx: 1495, cy: 62, r: 1.5, o: 0.7 },
  { cx: 1548, cy: 136, r: 1.1, o: 0.45 },
  { cx: 145, cy: 185, r: 1.0, o: 0.35 },
  { cx: 392, cy: 205, r: 1.1, o: 0.38 },
  { cx: 720, cy: 192, r: 1.0, o: 0.35 },
  { cx: 1210, cy: 180, r: 1.2, o: 0.42 },
  { cx: 1462, cy: 195, r: 1.1, o: 0.38 },
];

const PINE_TREES: { x: number; y: number; s: number; layer: 'back' | 'front' }[] = [
  // Left forest ridge
  { x: 38, y: 518, s: 1.05, layer: 'back' },
  { x: 78, y: 510, s: 1.25, layer: 'back' },
  { x: 120, y: 520, s: 0.95, layer: 'back' },
  { x: 162, y: 512, s: 1.3, layer: 'back' },
  { x: 208, y: 522, s: 1.1, layer: 'back' },
  { x: 252, y: 518, s: 1.2, layer: 'back' },
  { x: 298, y: 526, s: 0.95, layer: 'back' },
  { x: 344, y: 530, s: 1.08, layer: 'back' },
  { x: 392, y: 536, s: 0.9, layer: 'back' },
  { x: 438, y: 540, s: 0.85, layer: 'back' },
  // Town backdrop pines
  { x: 650, y: 532, s: 0.92, layer: 'back' },
  { x: 690, y: 524, s: 1.12, layer: 'back' },
  { x: 732, y: 528, s: 0.96, layer: 'back' },
  { x: 830, y: 518, s: 1.05, layer: 'back' },
  { x: 938, y: 516, s: 1.15, layer: 'back' },
  { x: 1030, y: 520, s: 1.0, layer: 'back' },
  { x: 1185, y: 518, s: 1.12, layer: 'back' },
  { x: 1338, y: 524, s: 1.05, layer: 'back' },
  { x: 1468, y: 516, s: 1.2, layer: 'back' },
  { x: 1518, y: 512, s: 1.32, layer: 'back' },
  { x: 1566, y: 520, s: 1.1, layer: 'back' },
  // Closer dark pine silhouettes
  { x: 18, y: 546, s: 1.35, layer: 'front' },
  { x: 64, y: 542, s: 1.45, layer: 'front' },
  { x: 112, y: 548, s: 1.2, layer: 'front' },
  { x: 156, y: 540, s: 1.5, layer: 'front' },
  { x: 204, y: 550, s: 1.25, layer: 'front' },
  { x: 248, y: 548, s: 1.15, layer: 'front' },
  { x: 292, y: 554, s: 1.0, layer: 'front' },
  { x: 336, y: 558, s: 0.92, layer: 'front' },
  { x: 1492, y: 546, s: 1.28, layer: 'front' },
  { x: 1545, y: 540, s: 1.45, layer: 'front' },
  { x: 1588, y: 552, s: 1.3, layer: 'front' },
];

const WATER_SPARKLES: { y: number; w: number; dx: number; o: number; warm: boolean }[] = [
  { y: 556, w: 120, dx: 0, o: 0.72, warm: true },
  { y: 568, w: 94, dx: -8, o: 0.62, warm: true },
  { y: 582, w: 112, dx: 10, o: 0.56, warm: true },
  { y: 598, w: 78, dx: -6, o: 0.48, warm: true },
  { y: 616, w: 96, dx: 12, o: 0.42, warm: true },
  { y: 636, w: 66, dx: -10, o: 0.35, warm: true },
  { y: 660, w: 82, dx: 6, o: 0.28, warm: true },
  { y: 688, w: 54, dx: -8, o: 0.22, warm: true },
  { y: 720, w: 68, dx: 10, o: 0.16, warm: true },
  { y: 758, w: 46, dx: -4, o: 0.12, warm: true },
  { y: 604, w: 145, dx: -390, o: 0.14, warm: false },
  { y: 646, w: 180, dx: -520, o: 0.12, warm: false },
  { y: 702, w: 220, dx: -260, o: 0.11, warm: false },
  { y: 742, w: 190, dx: 180, o: 0.12, warm: false },
  { y: 804, w: 240, dx: -420, o: 0.1, warm: false },
];

export const TitleBackdropSvg: React.FC = () => {
  return (
    <svg
      viewBox="0 0 1600 900"
      preserveAspectRatio="xMidYMid slice"
      className="w-full h-full block"
      role="img"
      aria-label="Aetheria coastal town, forest, and mountains at twilight"
    >
      <defs>
        {/* Purple-to-orange twilight sky */}
        <linearGradient id="twilightSky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#090f20" />
          <stop offset="24%" stopColor="#1b193a" />
          <stop offset="48%" stopColor="#3e2452" />
          <stop offset="72%" stopColor="#823750" />
          <stop offset="89%" stopColor="#cf6446" />
          <stop offset="100%" stopColor="#ee9e54" />
        </linearGradient>

        {/* Warm horizon sun/moon twilight halo */}
        <radialGradient id="twilightOrbGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#fff3c4" stopOpacity="0.95" />
          <stop offset="22%" stopColor="#ffd07b" stopOpacity="0.6" />
          <stop offset="55%" stopColor="#e87948" stopOpacity="0.22" />
          <stop offset="100%" stopColor="#e87948" stopOpacity="0" />
        </radialGradient>

        {/* Sea gradient */}
        <linearGradient id="twilightSea" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#26334d" />
          <stop offset="22%" stopColor="#17243a" />
          <stop offset="60%" stopColor="#0e1828" />
          <stop offset="100%" stopColor="#080e18" />
        </linearGradient>

        {/* Far & mid mountain gradients */}
        <linearGradient id="farMountainGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#2a2448" />
          <stop offset="100%" stopColor="#181b30" />
        </linearGradient>
        <linearGradient id="midMountainGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#1a1f36" />
          <stop offset="100%" stopColor="#0f1524" />
        </linearGradient>

        {/* Lighthouse beam cone */}
        <linearGradient id="lighthouseBeamGrad" x1="0" y1="0.5" x2="1" y2="0.5">
          <stop offset="0%" stopColor="#ffe799" stopOpacity="0.46" />
          <stop offset="60%" stopColor="#f5c262" stopOpacity="0.14" />
          <stop offset="100%" stopColor="#f5c262" stopOpacity="0" />
        </linearGradient>

        {/* Warm lantern glow halo */}
        <radialGradient id="lanternGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#ffe58f" stopOpacity="0.85" />
          <stop offset="45%" stopColor="#f5a642" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#f5a642" stopOpacity="0" />
        </radialGradient>

        {/* Moon reflection column */}
        <linearGradient id="seaReflectColumn" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ffb866" stopOpacity="0.38" />
          <stop offset="45%" stopColor="#e87a48" stopOpacity="0.16" />
          <stop offset="100%" stopColor="#e87a48" stopOpacity="0" />
        </linearGradient>
      </defs>

      {/* Sky Canvas */}
      <rect x="0" y="0" width="1600" height="560" fill="url(#twilightSky)" />

      {/* Stars */}
      <g>
        {STARS.map((s, idx) => (
          <g key={idx} opacity={s.o}>
            <circle cx={s.cx} cy={s.cy} r={s.r} fill="#fff4d6" />
            {s.cross && (
              <>
                <line x1={s.cx - s.r * 3} y1={s.cy} x2={s.cx + s.r * 3} y2={s.cy} stroke="#fff4d6" strokeWidth="0.9" />
                <line x1={s.cx} y1={s.cy - s.r * 3} x2={s.cx} y2={s.cy + s.r * 3} stroke="#fff4d6" strokeWidth="0.9" />
              </>
            )}
          </g>
        ))}
      </g>

      {/* Distant Floating Sky-Isle Silhouette (Aetheria nod) */}
      <g opacity="0.58">
        <path d="M1265 198 L1315 186 L1362 194 L1390 202 L1350 226 L1328 242 L1305 224 Z" fill="#282347" />
        <path d="M1308 188 L1318 164 L1328 188 Z" fill="#211d3c" />
        <circle cx="1320" cy="193" r="2.2" fill="#ffd984" />
      </g>

      {/* Soft Moon / Twilight Horizon Orb */}
      <circle cx="1115" cy="368" r="190" fill="url(#twilightOrbGlow)" />
      <circle cx="1115" cy="368" r="34" fill="#fff1c4" opacity="0.92" />
      <circle cx="1104" cy="362" r="28" fill="#ffe099" opacity="0.28" />

      {/* Soft Twilight Clouds */}
      <g opacity="0.34">
        <path
          d="M120 330 Q180 308 250 322 Q315 304 385 324 Q435 314 480 334 L100 338 Z"
          fill="#a94d5c"
        />
        <path
          d="M840 296 Q900 278 965 292 Q1035 272 1095 294 Q1150 286 1190 302 L820 304 Z"
          fill="#c46652"
        />
        <path
          d="M1220 336 Q1285 316 1350 330 Q1415 314 1480 334 L1200 340 Z"
          fill="#b45652"
        />
      </g>

      {/* Far Layered Mountain Silhouettes */}
      <path
        d="M0 545 L0 420 L95 365 L195 408 L310 315 L420 390 L535 335 L645 415 L770 342 L875 405 L990 352 L1105 426 L1225 328 L1355 398 L1465 310 L1600 388 L1600 545 Z"
        fill="url(#farMountainGrad)"
      />
      {/* Subtle golden-violet rim highlights on far peaks */}
      <path
        d="M310 315 L362 352 L345 362 L310 328 Z M770 342 L818 372 L804 380 L770 354 Z M1225 328 L1280 364 L1264 373 L1225 340 Z M1465 310 L1520 346 L1504 355 L1465 322 Z"
        fill="#d17758"
        opacity="0.22"
      />

      {/* Mid Layered Mountain Silhouettes */}
      <path
        d="M0 550 L0 460 L75 425 L165 462 L260 398 L368 468 L485 418 L602 478 L715 415 L830 475 L948 422 L1052 486 L1170 432 L1292 482 L1410 406 L1525 462 L1600 430 L1600 550 Z"
        fill="url(#midMountainGrad)"
      />

      {/* Foothills & Coastal Headland Base */}
      <path
        d="M0 560 L0 508 Q160 486 340 520 Q480 545 615 530 Q790 505 975 512 Q1125 518 1245 538 Q1385 508 1600 502 L1600 560 Z"
        fill="#101824"
      />

      {/* Dark Pine Forest Silhouettes */}
      <g>
        {PINE_TREES.map((t, i) => {
          const fill = t.layer === 'back' ? '#101a28' : '#09101a';
          const h = 38 * t.s;
          const w = 14 * t.s;
          return (
            <g key={i} transform={`translate(${t.x}, ${t.y})`}>
              <polygon points={`0,${-h} ${-w * 0.65},${-h * 0.48} ${w * 0.65},${-h * 0.48}`} fill={fill} />
              <polygon points={`0,${-h * 0.72} ${-w * 0.85},${-h * 0.22} ${w * 0.85},${-h * 0.22}`} fill={fill} />
              <polygon points={`0,${-h * 0.45} ${-w},0 ${w},0`} fill={fill} />
            </g>
          );
        })}
      </g>

      {/* Twilight Sea */}
      <rect x="0" y="544" width="1600" height="356" fill="url(#twilightSea)" />

      {/* Soft Horizon Glow Strip on Water */}
      <rect x="0" y="542" width="1600" height="10" fill="#e58c52" opacity="0.22" />

      {/* Soft Moon & Sunset Reflection Column on Sea */}
      <polygon points="1055,546 1175,546 1235,860 995,860" fill="url(#seaReflectColumn)" />
      <g>
        {WATER_SPARKLES.map((w, idx) => (
          <rect
            key={idx}
            x={1115 + w.dx - w.w / 2}
            y={w.y}
            width={w.w}
            height={w.warm ? 3 : 2}
            rx="1.5"
            fill={w.warm ? '#ffd37e' : '#5882a6'}
            opacity={w.o}
          />
        ))}
      </g>

      {/* Coastal Cliff & Stone Seawall for Brightfall Town */}
      <path
        d="M660 554 L690 526 L1010 518 L1085 538 L1075 562 L660 562 Z"
        fill="#131c29"
      />
      <path
        d="M1265 554 L1320 518 L1600 508 L1600 564 L1265 564 Z"
        fill="#111926"
      />
      <rect x="685" y="544" width="380" height="12" fill="#1b2636" />
      <line x1="685" y1="545" x2="1065" y2="545" stroke="#475b73" strokeWidth="1.5" opacity="0.5" />

      {/* Wooden Harbor Pier & Dock Lanterns */}
      <g>
        <rect x="860" y="556" width="128" height="7" fill="#231c1a" />
        <rect x="875" y="563" width="6" height="18" fill="#181312" />
        <rect x="915" y="563" width="6" height="18" fill="#181312" />
        <rect x="955" y="563" width="6" height="18" fill="#181312" />
        <rect x="980" y="563" width="6" height="18" fill="#181312" />
        {/* Pier lanterns */}
        <circle cx="918" cy="548" r="14" fill="url(#lanternGlow)" />
        <rect x="916" y="546" width="4" height="10" fill="#2e2420" />
        <circle cx="918" cy="546" r="2.5" fill="#ffe48c" />
        <circle cx="983" cy="548" r="14" fill="url(#lanternGlow)" />
        <rect x="981" y="546" width="4" height="10" fill="#2e2420" />
        <circle cx="983" cy="546" r="2.5" fill="#ffe48c" />
      </g>

      {/* Moored Sailboat Silhouette */}
      <g transform="translate(1038, 578)">
        <path d="M-24 0 L24 0 L16 10 L-16 10 Z" fill="#18202c" />
        <line x1="0" y1="0" x2="0" y2="-38" stroke="#293445" strokeWidth="2.2" />
        <polygon points="2,-35 20,-8 2,-6" fill="#243145" opacity="0.9" />
        <polygon points="-2,-30 -14,-8 -2,-7" fill="#1c2738" opacity="0.85" />
        <circle cx="-12" cy="-2" r="8" fill="url(#lanternGlow)" />
        <circle cx="-12" cy="-2" r="2" fill="#ffd97d" />
      </g>

      {/* Coastal Town Buildings with Glowing Warm Lantern Windows */}
      <g>
        {/* Cottage 1 (Left harbour house) */}
        <g transform="translate(715, 502)">
          <rect x="0" y="14" width="44" height="30" fill="#1b2433" />
          <polygon points="-5,15 22,-4 49,15" fill="#2c2436" />
          <rect x="31" y="-2" width="6" height="11" fill="#1b2433" />
          <circle cx="14" cy="28" r="14" fill="url(#lanternGlow)" />
          <rect x="10" y="24" width="8" height="8" rx="1" fill="#ffd978" />
          <circle cx="31" cy="28" r="14" fill="url(#lanternGlow)" />
          <rect x="27" y="24" width="8" height="8" rx="1" fill="#ffbe55" />
        </g>

        {/* Town Hall & Clock Spire */}
        <g transform="translate(772, 474)">
          <rect x="0" y="32" width="62" height="40" fill="#192231" />
          <polygon points="-4,33 31,12 66,33" fill="#2d2638" />
          {/* Clock Tower */}
          <rect x="20" y="-12" width="22" height="40" fill="#1e293b" />
          <polygon points="17,-12 31,-32 45,-12" fill="#3b2f45" />
          <circle cx="31" cy="2" r="6" fill="#ffd978" />
          <circle cx="31" cy="2" r="16" fill="url(#lanternGlow)" />
          <rect x="10" y="44" width="8" height="10" rx="1" fill="#ffd978" />
          <rect x="27" y="44" width="8" height="10" rx="1" fill="#ffbe55" />
          <rect x="44" y="44" width="8" height="10" rx="1" fill="#ffd978" />
          <circle cx="31" cy="49" r="20" fill="url(#lanternGlow)" />
        </g>

        {/* Gabled Inn / Cafe */}
        <g transform="translate(848, 496)">
          <rect x="0" y="16" width="54" height="34" fill="#1c2636" />
          <polygon points="-4,17 27,-3 58,17" fill="#352838" />
          <rect x="18" y="34" width="10" height="16" fill="#2a1d1a" />
          <circle cx="11" cy="28" r="13" fill="url(#lanternGlow)" />
          <rect x="7" y="24" width="8" height="8" rx="1" fill="#ffd978" />
          <circle cx="39" cy="28" r="13" fill="url(#lanternGlow)" />
          <rect x="35" y="24" width="8" height="8" rx="1" fill="#ffd978" />
          <circle cx="25" cy="11" r="11" fill="url(#lanternGlow)" />
          <circle cx="25" cy="11" r="3" fill="#ffe28a" />
        </g>

        {/* Harbor Warehouse & Shop */}
        <g transform="translate(914, 506)">
          <rect x="0" y="12" width="48" height="28" fill="#16202e" />
          <polygon points="-3,13 24,-2 51,13" fill="#282334" />
          <circle cx="14" cy="24" r="12" fill="url(#lanternGlow)" />
          <rect x="10" y="20" width="8" height="7" rx="1" fill="#ffbe55" />
          <circle cx="33" cy="24" r="12" fill="url(#lanternGlow)" />
          <rect x="29" y="20" width="8" height="7" rx="1" fill="#ffd978" />
        </g>

        {/* Hillside Cottage on Right */}
        <g transform="translate(1338, 496)">
          <rect x="0" y="12" width="42" height="26" fill="#151f2d" />
          <polygon points="-4,13 21,-3 46,13" fill="#2b2335" />
          <circle cx="13" cy="24" r="13" fill="url(#lanternGlow)" />
          <rect x="9" y="20" width="8" height="7" rx="1" fill="#ffd978" />
          <circle cx="29" cy="24" r="13" fill="url(#lanternGlow)" />
          <rect x="25" y="20" width="8" height="7" rx="1" fill="#ffbe55" />
        </g>

        {/* Town Street Lanterns */}
        {[704, 764, 840, 908, 968].map((lx, idx) => (
          <g key={idx} transform={`translate(${lx}, 538)`}>
            <circle cx="0" cy="-6" r="12" fill="url(#lanternGlow)" />
            <rect x="-1" y="-5" width="2" height="12" fill="#252f3d" />
            <circle cx="0" cy="-6" r="2.2" fill="#ffe48c" />
          </g>
        ))}

        {/* Town Lantern Reflection Shimmers in Harbor Water */}
        <g opacity="0.32">
          <rect x="730" y="566" width="14" height="2.5" rx="1" fill="#ffd273" />
          <rect x="785" y="574" width="20" height="2.5" rx="1" fill="#ffbe55" />
          <rect x="858" y="568" width="16" height="2.5" rx="1" fill="#ffd273" />
          <rect x="914" y="578" width="18" height="2.5" rx="1" fill="#ffd273" />
          <rect x="980" y="572" width="14" height="2.5" rx="1" fill="#ffe28a" />
        </g>
      </g>

      {/* Coastal Lighthouse on Eastern Point */}
      <g transform="translate(1395, 434)">
        {/* Light Beam Cone */}
        <polygon points="10,16 -250,-42 -250,48" fill="url(#lighthouseBeamGrad)" />
        {/* Tower */}
        <polygon points="0,86 6,18 20,18 26,86" fill="#1b2636" />
        <polygon points="2,64 24,64 23,54 3,54" fill="#2b3a4f" />
        <polygon points="4,42 22,42 21,32 5,32" fill="#2b3a4f" />
        {/* Lantern Room */}
        <rect x="4" y="8" width="18" height="11" fill="#ffe082" />
        <circle cx="13" cy="13" r="26" fill="url(#lanternGlow)" />
        <polygon points="1,8 13,-4 25,8" fill="#101824" />
        <rect x="2" y="18" width="22" height="3" fill="#0d141f" />
      </g>

      {/* Foreground Dark Rocky Coastline Framing Bottom Corners */}
      <path
        d="M0 900 L0 795 Q110 818 220 852 Q335 880 460 900 Z"
        fill="#060b12"
      />
      <path
        d="M1600 900 L1600 815 Q1480 830 1355 866 Q1245 890 1140 900 Z"
        fill="#060b12"
      />
    </svg>
  );
};
